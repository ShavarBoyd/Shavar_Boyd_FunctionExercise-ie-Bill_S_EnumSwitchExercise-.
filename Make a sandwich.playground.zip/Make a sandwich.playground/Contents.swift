enum Sandwhich {
    case Bread
    case Ham
    case Cheese
    case Bread2
}


var Building = Sandwhich.Bread


switch Building {
case .Bread:
    print("The roof of the sandwich")
case .Ham:
    print(" The meat of the sandwhich")
case .Cheese:
    print("the cheesy part of the sandwhich")
case .Bread2:
    print("The base of the sandwhich")
}


var Building2 = Sandwhich.Ham


switch Building2 {
case .Bread:
    print("The roof of the sandwich")
case .Ham:
    print(" The meat of the sandwhich")
case .Cheese:
    print("the cheesy part of the sandwhich")
case .Bread2:
    print("The base of the sandwhich")
}


var Building3 = Sandwhich.Cheese


switch Building2 {
case .Bread:
    print("The roof of the sandwich")
case .Ham:
    print(" The meat of the sandwhich")
case .Cheese:
    print("the cheesy part of the sandwhich")
case .Bread2:
    print("The base of the sandwhich")
}


var Building4 = Sandwhich.Bread2

switch Building4 {
case .Bread:
    print("The roof of the sandwich")
case .Ham:
    print(" The meat of the sandwhich")
case .Cheese:
    print("the cheesy part of the sandwhich")
case .Bread2:
    print("The base of the sandwhich")
}
